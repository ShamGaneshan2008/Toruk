TORUK exploratory replication overlay

Base checkout: 84ad607473f76b04f9dd1c2aaae2e3201f4ee0ca
Extract over that checkout; preserve supplied bytes. Pretrained weights are omitted.
Start: docs/research/independent-replication-v1/README.md
Reproduce: docs/research/independent-replication-v1/reproduce.md
Verdict: efficiency/quality claim NOT ESTABLISHED. Local draft only; no publication.
Each payload digest is in ZIP_PAYLOAD_SHA256.json. No .git, credentials or private notes.
