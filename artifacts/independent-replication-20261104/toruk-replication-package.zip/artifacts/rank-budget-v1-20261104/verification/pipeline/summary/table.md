| Measurement | Value |
| --- | --- |
| scope | ordinary-LM smoke fixture; no factual or memory claim |
| parameters | 44096 |
| steps | 2 |
| training_targets | 353 |
| validation_loss_nats_per_byte_or_eos | 5.395494337205763 |
| validation_targets | 154 |
| generated_tokens | 8 |
| saved_generation_seconds | 0.007795699999860517 |
| saved_mean_generation_ms | 7.795699999860517 |
| saved_generation_tokens_per_second | 1026.206755024326 |
| saved_training_seconds | 0.021559099999649334 |
| saved_training_tokens_per_second | 16373.596300668472 |
| checkpoint_sha256 | df99da343fd8d3c9d72c972b0f9f606facdc5f49b6f882df5c640e59682fc81d |
| run_manifest_sha256 | 2372f39458d1464a21fdbd9a26d5b1855df5f86d5872c71e973d2fbbe93f693f |
| uncertainty | NOT_TESTED; one seed and synthetic fixture |
| recurrent_state_bytes | 0 |
| peak_memory_bytes | None |
| timing_note | stored run timings; rescore/generation verify outputs but do not replace timings |
