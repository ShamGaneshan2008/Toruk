| Measurement | Value |
| --- | --- |
| scope | ordinary-LM smoke fixture; no factual or memory claim |
| parameters | 44096 |
| steps | 2 |
| training_targets | 353 |
| validation_loss_nats_per_byte_or_eos | 5.395494337205763 |
| validation_targets | 154 |
| generated_tokens | 8 |
| saved_generation_seconds | 0.007937899999888032 |
| saved_mean_generation_ms | 7.937899999888032 |
| saved_generation_tokens_per_second | 1007.8232278200587 |
| saved_training_seconds | 0.019592200000261073 |
| saved_training_tokens_per_second | 18017.374260945486 |
| checkpoint_sha256 | df99da343fd8d3c9d72c972b0f9f606facdc5f49b6f882df5c640e59682fc81d |
| run_manifest_sha256 | ea7c936980e340ad279e75f70b9390f3e8d1cd34c06bf082634f270c531f6d17 |
| uncertainty | NOT_TESTED; one seed and synthetic fixture |
| recurrent_state_bytes | 0 |
| peak_memory_bytes | None |
| timing_note | stored run timings; rescore/generation verify outputs but do not replace timings |
