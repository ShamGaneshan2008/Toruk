# Milestone status

Initial audit: branch `main`, clean tree, base
`334fe510780bda7b622ae7821a970c40d9f7dd2a`. Only tracked files were the PyCharm
starter `main.py` and `.idea/.gitignore`. No README, AGENTS.md, package,
configurations, specs, milestones, experiments, tests or workflows existed.
Ancestor AGENTS.md locations were checked; none were present. `main.py` is kept.

| Dependency | Actual status |
| --- | --- |
| Ordinary causal LM foundation (M1 prerequisite) | Implemented in this working tree; see checks and experiment registry for verification |
| Controlled-world generator, independent oracle, task evaluation (M2 prerequisite) | Implemented v1 during M6 prerequisite recovery; independent oracle, frozen worlds, generated-answer CLI and tests |
| M3 recurrent-memory LM | Implemented bounded one-lane training, state/session isolation and drained-document resume; useful-memory benefit not established |
| M4 paired-branch effect predictor | Implemented and pilot executed; 50% sign ranking on four validation labels, all runtime decisions out of support; learned value unestablished |
| M5 correction and preservation | Implemented separate objectives and final-write prediction; pilot known-fact correction/preservation accuracy 0%; research hypothesis unestablished |
| M6 controlled comparisons | PARTIAL: 14 validation configurations completed; all 0% primary accuracy; one seed, final test closed, exact resource matching outstanding |
| Protected revisions | Not started |

The following foundation handoff and audit sections are historical; the recovery
and registered pilot are recorded in the final section.

The explicit dependency rule in the task prevents building memory experiments
on this initially absent baseline. This handoff completes the earliest ordinary
LM foundation, then stops before M2/M3 rather than inventing prior-stage evidence.

Remaining M3 work: validate M2's world/event generator against an independently
implemented oracle, split documents, add autoregressive task scoring and a
trained ordinary baseline; then implement the proposed state/read/write contract,
ordered document lanes, TBPTT, streaming sessions and branching, safe memory
resume, architectural tests, and a matched-budget validation-only comparison.
Measure delayed/corrected/unchanged/distractor/density/unknown tasks, evidence
distance, coverage, parameters/state bytes, memory and full-history timing.

Before M4: M1/M2 must pass; all M3 causal/gradient/reset/session/resume tests must
pass; retain reproducible raw validation predictions for a fair ordinary/memory
comparison and reset-memory ablation with its distribution-shift caveat. A null
benefit may be reported but requires update/gradient/order/scoring/training
diagnostics. Then define paired branches and future-outcome labels without
oracle leakage. No claimed Toruk novelty follows from a recurrent baseline.

## 2026-10-20 M4 prerequisite re-audit

At `a025f0148965089b24a69344a13cd8a6447afef9` on `main`, the source, tests,
public commands and artifacts still contain only the ordinary LM. Fresh local
checks passed (9 tests), and a bounded foundation reproduction retained raw
validation outputs. Exact-commit remote CPU foundation CI also passed. This does
not verify recurrent memory: there is no writer/state/session/TBPTT code, M2
oracle or memory comparison. No M3 correctness fix or M4 implementation is claimed.

See [audit and reproduction](research/m4-prerequisite-audit.md),
[conditional M4 protocol](research/m4-effect-predictor.md), and
[primary-paper assessment](research/related-work.md). The new documents/evidence
are local edits; no commit or push was performed for this task. The next required
work remains M2 followed by M3 verification, before paired predictor training.

## 2026-10-20 M5 prerequisite gate

The source/configuration/test/workflow hashes still match the verified M4 audit.
No M4 branch pipeline, predictor or recurrent baseline exists. M5 therefore stops
at the explicit prerequisite gate; no correction/preservation experiment or
milestone completion is claimed. Prior local foundation checks and exact-commit
remote results are reused as such, not reported as M5 results. See the
[M5 audit](research/m5-prerequisite-audit.md) and
`artifacts/m5-prerequisite-audit.json`. Existing edits remain uncommitted/unpushed.

## 2026-10-20 prerequisite recovery and bounded M6 execution

The preceding audit sections describe the pre-implementation tree. Subsequent
M6 work implemented controlled worlds/oracle, recurrent state/session/training/
resume, paired labels/predictor and explicit correction/preservation losses.
A 14-result validation pilot completed under a 120-second process timeout but
did not learn corrected or preserved known facts. No mechanism or training
extension was added after observing registered results. See
[results](research/m6-results.md), [protocol](research/m6-validation-protocol.md),
and `artifacts/m6-validation-001/{protocol,stages,summary,manifest}.json`.
Local 24-test/lint/format/type/package checks pass; new code is NOT_RUN remotely.
No final test, commit, push, paid compute or M6 completion claim.
